const mongoose = require("mongoose");

const propertySchema = new mongoose.Schema(
{
    title:{
        type:String,
        required:true
    },

    description:{
        type:String,
        required:true
    },

    location:{
        type:String,
        required:true
    },

    price:{
        type:Number,
        required:true
    },

    bedrooms:{
        type:Number,
        required:true
    },

    bathrooms:{
        type:Number,
        required:true
    },

    image:{
        type:String,
        default:"https://via.placeholder.com/500x300"
    },

    virtualTour: {
        type: String,
        default: ""
    },

    owner:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User"
    }

},
{
    timestamps:true
});

module.exports = mongoose.model("Property",propertySchema);